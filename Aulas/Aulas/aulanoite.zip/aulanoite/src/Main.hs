module Main where

import Data.List(sort)
import Test.QuickCheck

-- Decide se todos os valores lógicos de uma lista são True
and2 :: [Bool] -> Bool
and2 [] = True
and2 (x:xs) = x && and2 xs

and3 :: [Bool] -> Bool
and3 xs = foldr (&&) True xs

-- >>> :t foldr
-- foldr :: Foldable t => (a -> b -> b) -> b -> t a -> b

-- Concatena uma lista de listas
concat2 :: [[a]] -> [a]
concat2 [] = []
concat2 ([]:xss) = concat2 xss
concat2 ((x:xs):xss) = x : concat2 (xs : xss)


-- [[1,2],[3,4]] 
-- x 1 xs [2] xss [[3,4]] 
-- [[3,4]]


-- Produz uma lista com n valores idênticos
replicate2 :: Int -> a -> [a]
replicate2 n _ | n <= 0 = []
replicate2 n x = x : replicate2 (n - 1) x

-- Seleciona o enésimo elemento de uma lista
(!!!) :: [a] -> Int -> a
[] !!! _ = error "nao pode"
(x:_) !!! 0 = x
(_:xs) !!! n = xs !!! (n - 1)

minimo :: Ord a => [a] -> a
minimo [x] = x
minimo (x:xs) = if x < mxs then x else mxs
  where
    mxs = minimo xs

remove :: Eq a => a -> [a] -> [a]
remove _ [] = []
remove v (x:xs)
  | v == x = xs
  | otherwise = x : remove v xs

ssort :: Ord a => [a] -> [a]
ssort [] = []
ssort xs = m : ssort xs'
  where
    m = minimo xs
    xs' = remove m xs


prop_tamanho :: Ord a => ([a] -> [a]) -> [a] -> Bool
prop_tamanho f xs = length (f xs) == length xs

prop_modelo :: ([Int] -> [Int]) -> [Int] -> Bool
prop_modelo f xs = f xs == sort xs

prop_idem :: ([Int] -> [Int]) -> [Int] -> Bool
prop_idem f xs = f (f xs) == f xs

merge :: Ord a => [a] -> [a] -> [a]
merge [] ys = ys
merge xs [] = xs
merge x0@(x : xs) y0@(y:ys)
  | x < y = x : merge xs y0
  | otherwise = y : merge x0 ys

split2 :: [a] -> ([a], [a])
split2 = split2' [] []
  where
    split2' ls rs [] = (ls, rs)
    split2' ls rs (x:xs) = (x : ls1, rs1)
      where
        (rs1, ls1) = split2' rs ls xs


msort :: Ord a => [a] -> [a]
msort [] = []
msort [x] = [x]
msort xs = merge (msort lxs) (msort rxs)
  where
    (lxs, rxs) = split2 xs






main :: IO ()
main = do
  print "banana"
  quickCheck (prop_tamanho ssort :: [Int] -> Bool)
  quickCheck (prop_tamanho ssort :: [Char] -> Bool)
  quickCheck $ prop_modelo ssort
  quickCheck $ prop_idem ssort
  quickCheck (prop_tamanho msort :: [Int] -> Bool)
  quickCheck (prop_tamanho msort :: [Char] -> Bool)
  quickCheck $ prop_modelo msort
  quickCheck $ prop_idem msort

